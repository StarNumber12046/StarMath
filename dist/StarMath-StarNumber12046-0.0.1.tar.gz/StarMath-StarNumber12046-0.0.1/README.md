# StarMath
## Installing
to install the package do *pip install starmath*
## How to use this package**
### Examples
#### Factorial N
``` py
import starmath
starmath.factorial(4) #number must be an int
```

#### Addition
``` py
import starmath
starmath.addition(4, 5) # you need two int
```